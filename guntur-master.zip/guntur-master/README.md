Cara Pasang

  -   Download/Clone Zip
  -   buat folder dengan nama terserah (misal product) anda pada folder c:/xampp/htdoct
  -   extrak dan pindah ke folder c:/xampp/htdoct/product
  -   nyalakan xampp dan buat database dengan nama barang
  -   import barang.sql pada folder tadi
  
setelah selesai panggil di browser dengan ketik http://localhost/product
